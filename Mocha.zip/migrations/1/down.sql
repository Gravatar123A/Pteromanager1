
DROP INDEX idx_webhook_configs_active;
DROP INDEX idx_server_logs_event_type;
DROP INDEX idx_server_logs_server_id;
DROP INDEX idx_servers_category;
DROP INDEX idx_servers_status;
DROP TABLE webhook_configs;
DROP TABLE server_logs;
DROP TABLE servers;
