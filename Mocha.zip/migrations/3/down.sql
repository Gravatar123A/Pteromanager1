
DROP INDEX idx_user_api_configs_user_id;
DROP TABLE user_api_configs;
